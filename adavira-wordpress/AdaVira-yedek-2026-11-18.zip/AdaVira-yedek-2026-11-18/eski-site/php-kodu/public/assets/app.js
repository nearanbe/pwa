(function(){var d=document;
d.querySelectorAll('.tabs').forEach(function(w){var bs=w.querySelectorAll('.tab');bs.forEach(function(b){b.addEventListener('click',function(){bs.forEach(function(x){x.setAttribute('aria-selected',x===b);var p=d.getElementById('p-'+x.dataset.i);if(p)p.hidden=x!==b;});});});});
var m=d.getElementById('menu'),n=d.getElementById('nav');if(m)m.addEventListener('click',function(){var o=n.classList.toggle('open');m.setAttribute('aria-expanded',o);});
var ph=d.getElementById('phone'),cc=d.getElementById('cc');
function fmt(){var v=ph.value.replace(/\D/g,'');if(cc.value==='90'){v=v.replace(/^0/,'').slice(0,10);var o='';if(v.length){o='('+v.slice(0,3);if(v.length>3)o+=') '+v.slice(3,6);if(v.length>6)o+=' '+v.slice(6,8);if(v.length>8)o+=' '+v.slice(8,10);}ph.value=o;ph.placeholder='(5xx) xxx xx xx';}else{ph.value=v.slice(0,14);ph.placeholder='Telefon numaranız';}}
if(ph&&cc){ph.addEventListener('input',fmt);cc.addEventListener('change',fmt);}
})();
