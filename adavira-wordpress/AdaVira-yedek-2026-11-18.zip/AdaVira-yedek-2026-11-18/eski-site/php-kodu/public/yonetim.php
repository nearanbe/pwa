<?php
require __DIR__.'/../inc/boot.php';session_start();header('X-Robots-Tag: noindex');
if(isset($_GET['cikis'])){session_destroy();header('Location: /yonetim.php');exit;}
if(!isset($_SESSION['t']))$_SESSION['t']=bin2hex(random_bytes(16));
$post=$_SERVER['REQUEST_METHOD']==='POST'&&hash_equals($_SESSION['t'],$_POST['t']??'');$err='';
if($post&&isset($_POST['email'])){$q=db()->prepare('SELECT * FROM admins WHERE email=?');$q->execute([$_POST['email']]);$u=$q->fetch();if($u&&password_verify($_POST['pass'],$u['pass_hash'])){session_regenerate_id(true);$_SESSION['a']=1;$_SESSION['t']=bin2hex(random_bytes(16));}else $err='Hatalı giriş';}
if(isset($_GET['upload'])){header('Content-Type: application/json; charset=utf-8');
 if(empty($_SESSION['a'])||!hash_equals($_SESSION['t'],$_POST['t']??'')){http_response_code(403);echo json_encode(['error'=>'Oturum süresi doldu, sayfayı yenileyip tekrar deneyin.']);exit;}
 $f=$_FILES['file']??null;if(!$f||$f['error']!==UPLOAD_ERR_OK){echo json_encode(['error'=>($f&&in_array($f['error'],[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true))?'Dosya sunucunun izin verdiği boyuttan büyük.':'Yükleme başarısız.']);exit;}
 echo json_encode(img_process($f['tmp_name'],$f['name'],($_POST['kind']??'')==='cover'?'cover':'content'),JSON_UNESCAPED_SLASHES);exit;}
$css='<meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><link rel=stylesheet href=/assets/quill/quill.snow.css><link rel=stylesheet href="/assets/admin.css?v='.@filemtime(__DIR__.'/assets/admin.css').'">';
if(empty($_SESSION['a'])){echo $css.'<form method=post style="max-width:340px;margin:60px auto"><h2>AdaVira Yönetim</h2><input type=hidden name=t value="'.$_SESSION['t'].'"><input name=email type=email placeholder="E-posta" required><input type=password name=pass placeholder="Şifre" required><button>Giriş</button> '.e($err).'</form>';exit;}
mig();
$tab=in_array($_GET['t']??'',['blog','haber','hakkimizda','mesajlar'],true)?$_GET['t']:'blog';
$DEF='<p>AdaVira, Girne merkezli bir dijital ajanstır. Emlak, oto galeri, güzellik, spor, sağlık, e-ticaret, otel ve turizm işletmelerinin internette görünür olması ve daha fazla müşteriye ulaşması için çalışıyoruz.</p>';
function go($t,$m,$k='ok'){header('Location: ?t='.$t.'&'.$k.'='.urlencode($m));exit;}
if($post&&isset($_POST['page'])){$bd=clean_html($_POST['body']??'');if(trim(strip_tags($bd))==='')go('hakkimizda','İçerik boş olamaz','er');
 $im=img_ok($_POST['image']??'');db()->prepare('REPLACE INTO pages(slug,title,excerpt,body,image,image_alt,image_w,image_h) VALUES(?,?,?,?,?,?,?,?)')->execute(['hakkimizda',trim($_POST['title']??'')?:'Hakkımızda',trim($_POST['excerpt']??''),$bd,$im,$im?mb_substr(trim($_POST['image_alt']??''),0,200):'',$im?(int)($_POST['image_w']??0):0,$im?(int)($_POST['image_h']??0):0]);go('hakkimizda','Kaydedildi');}
if($post&&isset($_POST['title'])){$id=(int)($_POST['id']??0);$ty=($_POST['type']??'')==='haber'?'haber':'blog';$ti=trim($_POST['title']);$ex=trim($_POST['excerpt']??'');$bd=clean_html($_POST['body']??'');$im=img_ok($_POST['image']??'');$ia=$im?mb_substr(trim($_POST['image_alt']??''),0,200):'';$iw=$im?(int)($_POST['image_w']??0):0;$ih=$im?(int)($_POST['image_h']??0):0;
 if($ti===''||trim(strip_tags($bd))==='')go($ty,'Başlık ve içerik boş olamaz','er');
 if($id)db()->prepare('UPDATE posts SET title=?,excerpt=?,body=?,image=?,image_alt=?,image_w=?,image_h=?,updated_at=NOW() WHERE id=?')->execute([$ti,$ex,$bd,$im,$ia,$iw,$ih,$id]);
 else{$sl=slugify($ti)?:'yazi';$base=$sl;$i=1;while(true){$c=db()->prepare('SELECT 1 FROM posts WHERE slug=?');$c->execute([$sl]);if(!$c->fetch())break;$i++;$sl=$base.'-'.$i;}
  db()->prepare('INSERT INTO posts(type,slug,title,excerpt,body,image,image_alt,image_w,image_h) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$ty,$sl,$ti,$ex,$bd,$im,$ia,$iw,$ih]);}
 go($ty,'Kaydedildi');}
if($post&&isset($_POST['del'])){db()->prepare('DELETE FROM posts WHERE id=?')->execute([(int)$_POST['del']]);go($tab,'Silindi');}
if($post&&isset($_POST['mdel'])){db()->prepare('DELETE FROM messages WHERE id=?')->execute([(int)$_POST['mdel']]);go('mesajlar','Silindi');}
function editor($html){
 global $SERVICES,$SECTORS;
 $o='<option value="">Seçili kelimeye site içi bağlantı ekle…</option><optgroup label="Sayfalar"><option value="/">Ana sayfa</option><option value="/hizmetler">Hizmetler</option><option value="/sektorler">Sektörler</option><option value="/hakkimizda">Hakkımızda</option><option value="/iletisim">İletişim</option><option value="/blog">Blog</option><option value="/bizden-haberler">Bizden Haberler</option></optgroup><optgroup label="Hizmetler">';
 foreach($SERVICES as $s=>$v)$o.='<option value="/hizmet/'.$s.'">'.e($v[0]).'</option>';
 $o.='</optgroup><optgroup label="Sektörler">';foreach($SECTORS as $s=>$v)$o.='<option value="/sektor/'.$s.'">'.e(explode(':',$v[0])[0]).'</option>';
 $o.='</optgroup><optgroup label="Yazılar">';foreach(db()->query('SELECT type,slug,title FROM posts ORDER BY id DESC LIMIT 100') as $r)$o.='<option value="/'.($r['type']==='blog'?'blog':'bizden-haberler').'/'.e($r['slug']).'">'.e($r['title']).'</option>';
 $o.='</optgroup>';
 $js=<<<'JS'
(function(){var q=new Quill('#ed',{theme:'snow',placeholder:'Yazınızı buraya yazın...',modules:{toolbar:[[{header:[2,3,false]}],[{size:['small',false,'large','huge']}],['bold','italic','underline','strike'],[{list:'ordered'},{list:'bullet'}],[{align:[]}],['blockquote','link','image'],['clean']]}});
var tb=q.getModule('toolbar');tb.addHandler('image',function(){var inp=document.createElement('input');inp.type='file';inp.accept='image/jpeg,image/png,image/webp';inp.onchange=function(){var fl=inp.files[0];if(!fl)return;var alt=prompt('Görselin kısa açıklaması (alt metin, Google için önemli):','');if(alt===null)return;var rg=q.getSelection(true);upl(fl,'content').then(function(r){if(r.error){alert(r.error);return;}q.insertEmbed(rg.index,'image',r.url,'user');[].forEach.call(q.root.querySelectorAll('img'),function(im){if(im.getAttribute('src')===r.url){im.setAttribute('alt',alt);im.setAttribute('width',r.w);im.setAttribute('height',r.h);}});q.setSelection(rg.index+1,0);}).catch(function(){alert('Görsel yüklenemedi.');});};inp.click();});
var last=null;q.on('selection-change',function(r){if(r)last=r.length?r:null;});
var il=document.getElementById('il');il.onchange=function(){if(!il.value)return;if(!last){alert('Önce metinde bağlantı vermek istediğiniz kelimeyi fare ile seçin.');}else{q.formatText(last.index,last.length,'link',il.value,'user');}il.value='';};
var bd=document.getElementById('bd');bd.form.addEventListener('submit',function(){bd.value=q.root.innerHTML;});})();
JS;
 return '<label>İçerik</label><select id=il>'.$o.'</select><div id=ed>'.$html.'</div><input type=hidden name=body id=bd><p><small>Görsel eklemek için araç çubuğundaki resim simgesini kullanın. Bir kelimeyi seçin, araç çubuğundaki bağlantı simgesine tıklayıp adresi yazın. Ya da kelimeyi seçip yukarıdan site içi bir sayfa seçin.</small></p><script src=/assets/quill/quill.min.js></script><script>'.$js.'</script>';
}
function cover_field($p,$alt,$w,$h){
 $js=<<<'JS'
(function(){var f=document.getElementById('cf'),s=document.getElementById('cs');
f.onchange=function(){if(!f.files[0])return;s.textContent='Yükleniyor…';upl(f.files[0],'cover').then(function(r){if(r.error){s.textContent=r.error;return;}s.textContent='Yüklendi';document.getElementById('ci').value=r.url;document.getElementById('cw').value=r.w;document.getElementById('ch').value=r.h;document.getElementById('cv').innerHTML='<img src="'+r.url+'" style="max-width:100%;max-height:220px;border-radius:8px">';}).catch(function(){s.textContent='Yükleme hatası';});};
document.getElementById('cx').onclick=function(){document.getElementById('ci').value='';document.getElementById('cw').value=0;document.getElementById('ch').value=0;document.getElementById('cv').innerHTML='';s.textContent='';f.value='';};})();
JS;
 return '<div class="c"><label>Başlık görseli (kapak)</label><p><small>Yatay (16:9) ve en az 1200 piksel genişlikte olması en iyisidir. JPG, PNG veya WebP yükleyin; site otomatik olarak küçültür ve hızlı formata çevirir.</small></p><div id=cv>'.($p?'<img src="'.e($p).'" style="max-width:100%;max-height:220px;border-radius:8px">':'').'</div><input type=file id=cf accept="image/jpeg,image/png,image/webp"> <span id=cs></span><input type=hidden name=image id=ci value="'.e($p).'"><input type=hidden name=image_w id=cw value="'.(int)$w.'"><input type=hidden name=image_h id=ch value="'.(int)$h.'"><label>Görsel açıklaması (alt metin, Google için önemli)</label><input name=image_alt maxlength=200 value="'.e($alt).'" placeholder="Örn. Girne merkezli dijital ajans ekibi toplantı yaparken"><button type=button class="b g" id=cx>Görseli kaldır</button></div><script>'.$js.'</script>';
}
$mc=(int)db()->query('SELECT COUNT(*) FROM messages')->fetchColumn();$T=$_SESSION['t'];
$tabs=['blog'=>'Blog','haber'=>'Bizden Haberler','hakkimizda'=>'Hakkımızda','mesajlar'=>'Mesajlar ('.$mc.')'];
echo $css.'<p style="display:flex;justify-content:space-between;align-items:center"><b>AdaVira Yönetim</b><a class="b g" href="?cikis=1">Çıkış</a></p><div class="tabs">';
foreach($tabs as $k=>$v)echo '<a class="'.($tab===$k?'on':'').'" href="?t='.$k.'">'.e($v).'</a>';echo '</div>';
echo '<script>var TOK="'.$_SESSION['t'].'";function upl(file,kind){var fd=new FormData();fd.append("file",file);fd.append("t",TOK);fd.append("kind",kind);return fetch("/yonetim.php?upload=1",{method:"POST",body:fd,credentials:"same-origin"}).then(function(r){return r.json()});}</script>';
if(!empty($_GET['ok']))echo '<p class="ok">'.e($_GET['ok']).'</p>';if(!empty($_GET['er']))echo '<p class="er">'.e($_GET['er']).'</p>';
if($tab==='mesajlar'){
 foreach(db()->query('SELECT * FROM messages ORDER BY id DESC LIMIT 100') as $m){$d=preg_replace('/\D/','',$m['phone']);
  echo '<div class="c"><b>'.e($m['name']).'</b> <small>'.e($m['created_at']).'</small><br>';
  if($m['phone'])echo '<a class="b" href="tel:+'.$d.'">Ara '.e($m['phone']).'</a> <a class="b g" href="https://wa.me/'.$d.'" target="_blank">WhatsApp</a><br>';
  if($m['email'])echo e($m['email']).'<br>';
  echo '<p>'.nl2br(e($m['body'])).'</p><form method=post onsubmit="return confirm(\'Mesaj silinsin mi?\')"><input type=hidden name=t value="'.$T.'"><button class="d" name=mdel value="'.(int)$m['id'].'">Sil</button></form></div>';}
 if(!$mc)echo '<p>Henüz mesaj yok.</p>';
}elseif($tab==='hakkimizda'){
 $q=db()->prepare('SELECT * FROM pages WHERE slug=?');$q->execute(['hakkimizda']);$pg=$q->fetch()?:[];
 echo '<div class="c"><h3>Hakkımızda sayfası</h3><form method=post><input type=hidden name=t value="'.$T.'"><input type=hidden name=page value=1>
 <label>Sayfa başlığı</label><input name=title value="'.e($pg['title']??'Hakkımızda').'" required><label>Google açıklaması (en fazla 160 karakter)</label><input name=excerpt maxlength=300 value="'.e($pg['excerpt']??'').'">'.cover_field($pg['image']??'',$pg['image_alt']??'',$pg['image_w']??0,$pg['image_h']??0).editor(($pg&&trim(strip_tags($pg['body'])))?$pg['body']:$DEF).'<button>Kaydet</button> <a class="b g" href="/hakkimizda" target="_blank">Sayfayı gör</a></form></div>';
}else{
 $nm=$tab==='blog'?'Blog':'Bizden Haberler';$edit=null;
 if(isset($_GET['d'])){$q=db()->prepare('SELECT * FROM posts WHERE id=?');$q->execute([(int)$_GET['d']]);$edit=$q->fetch()?:null;}
 echo '<div class="c"><h3>'.($edit?'Yazıyı düzenle':'Yeni '.$nm.' yazısı ekle').'</h3><form method=post><input type=hidden name=t value="'.$T.'"><input type=hidden name=type value="'.$tab.'"><input type=hidden name=id value="'.(int)($edit['id']??0).'">
 <label>Başlık</label><input name=title required value="'.e($edit['title']??'').'"><label>Kısa özet (Google açıklaması, en fazla 160 karakter)</label><input name=excerpt maxlength=300 value="'.e($edit['excerpt']??'').'">'.cover_field($edit['image']??'',$edit['image_alt']??'',$edit['image_w']??0,$edit['image_h']??0).editor($edit['body']??'').'<button>'.($edit?'Güncelle':'Yayınla').'</button> '.($edit?'<a class="b g" href="?t='.$tab.'">Vazgeç</a>':'').'</form></div><h3>Yayındaki yazılar</h3>';
 $q=db()->prepare('SELECT id,slug,title,created_at FROM posts WHERE type=? ORDER BY id DESC');$q->execute([$tab]);$n=0;
 foreach($q as $r){$n++;echo '<div class="c"><b>'.e($r['title']).'</b><br><small>'.e(date('d.m.Y',strtotime($r['created_at']))).'</small><br><br><a class="b g" href="/'.($tab==='blog'?'blog':'bizden-haberler').'/'.e($r['slug']).'" target="_blank">Görüntüle</a> <a class="b g" href="?t='.$tab.'&d='.(int)$r['id'].'">Düzenle</a> <form method=post style="display:inline" onsubmit="return confirm(\'Bu yazı silinsin mi?\')"><input type=hidden name=t value="'.$T.'"><button class="d" name=del value="'.(int)$r['id'].'">Sil</button></form></div>';}
 if(!$n)echo '<p>Henüz yazı yok.</p>';
}
