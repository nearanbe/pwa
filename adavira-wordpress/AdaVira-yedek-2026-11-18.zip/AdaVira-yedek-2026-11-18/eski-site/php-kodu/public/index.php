<?php
require __DIR__.'/../inc/boot.php';
$p=explode('/',trim(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH),'/'));$a=$p[0];$b=$p[1]??null;
function cards($arr,$base,$i=1){$h='<div class="grid">';foreach($arr as $s=>$v)$h.='<a class="card" href="'.$base.$s.'"><h3>'.e($v[0]).'</h3><p>'.e($v[$i+1]).'</p></a>';return $h.'</div>';}
function posts($t,$n=50){try{$q=db()->prepare('SELECT * FROM posts WHERE type=? AND published=1 ORDER BY created_at DESC LIMIT '.(int)$n);$q->execute([$t]);return $q->fetchAll();}catch(Throwable $x){return[];}}
function plist($rows,$base,$grid=false){if(!$rows)return '<p>Yakında yeni içerikler eklenecek.</p>';$h='<ul class="plist'.($grid?' cards':'').'">';foreach($rows as $r){$u=$base.'/'.e($r['slug']);$al=($r['image_alt']??'')?:$r['title'];
 $h.='<li>'.(($r['image']??'')?'<a class="th" href="'.$u.'" tabindex="-1" aria-hidden="true">'.img_tag($r['image'],$al,$r['image_w']??0,$r['image_h']??0,'(max-width:820px) 100vw, 340px').'</a>':'').'<h3><a href="'.$u.'">'.e($r['title']).'</a></h3><p>'.e($r['excerpt']).'</p><time>'.e(date('d.m.Y',strtotime($r['created_at']))).'</time></li>';}return $h.'</ul>';}
function sector_tabs($S){global $SLOG;$t='';$pn='';$i=0;foreach($S as $s=>$v){$li='';foreach($v[3] as $m)$li.='<li>'.e($m).'</li>';
 $t.='<button type="button" class="tab" role="tab" data-i="'.$s.'" aria-selected="'.($i?'false':'true').'">'.e(explode(':',$v[0])[0]).'</button>';
 $pn.='<div class="panel" role="tabpanel" id="p-'.$s.'"'.($i?' hidden':'').'><h3>'.e($SLOG[$s][0]).'</h3><p>'.e($SLOG[$s][1]).'</p><ul>'.$li.'</ul><a class="more" href="/sektor/'.$s.'">'.e($v[1]).' →</a></div>';$i++;}
 return '<div class="sectors"><div class="tabs" role="tablist" aria-label="Sektörler">'.$t.'</div><div>'.$pn.'</div></div>';}
function svc_grid($S){$h='<div class="svcs">';foreach($S as $s=>$v)$h.='<a class="svc" href="/hizmet/'.$s.'"><h3>'.e($v[0]).'</h3><p>'.e($v[2]).'</p></a>';return $h.'</div>';}
function steps(){return '<ol class="steps"><li><h3>Tanışma ve analiz</h3><p>İşletmenizi, rakiplerinizi ve mevcut dijital varlığınızı inceleriz.</p></li><li><h3>Strateji ve teklif</h3><p>Hedefe uygun hizmetleri, takvimi ve fiyatı yazılı sunarız.</p></li><li><h3>Üretim</h3><p>Site, içerik ve çekimler onayınızla hazırlanır.</p></li><li><h3>Yayın ve raporlama</h3><p>Yayına alır, sonuçları aylık raporlarız.</p></li></ol>';}
function captcha_ok(){
 if(time()-($_SESSION['ts']??time())<3||time()-($_SESSION['last']??0)<30)return false;
 if(env('TURNSTILE_SITEKEY')&&env('TURNSTILE_SECRET')){
  $r=@file_get_contents('https://challenges.cloudflare.com/turnstile/v0/siteverify',false,stream_context_create(['http'=>['method'=>'POST','header'=>'Content-Type: application/x-www-form-urlencoded','content'=>http_build_query(['secret'=>env('TURNSTILE_SECRET'),'response'=>$_POST['cf-turnstile-response']??'','remoteip'=>$_SERVER['REMOTE_ADDR']??'']),'timeout'=>5]]));
  $j=$r?json_decode($r,true):null;return !empty($j['success']);}
 return (int)($_POST['cap']??-1)===(($_SESSION['a']??0)+($_SESSION['b']??0));
}
switch(true){
case $a==='':
 ob_start();?>
<section class="w hero"><h1>Kıbrıs Dijital Ajans: Web Tasarım, SEO ve Video Prodüksiyon</h1><p class="lead">Markanızın dijital rotasını çiziyoruz. Web sitesi, SEO, sosyal medya, reklam ve profesyonel video çekimi tek ekipte.</p><div class="actions"><a class="btn" href="/iletisim">Ücretsiz analiz iste</a><a class="btn ghost" href="https://wa.me/<?=wa()?>" target="_blank" rel="noopener">WhatsApp'tan yazın</a></div></section>
<div class="band" id="sektorler"><div class="w"><h2>Sektörünüzü tanıyan bir ekip</h2><p class="lead">Her sektörün müşterisi farklı karar verir. Çalışmamızı buna göre kurarız.</p><?=sector_tabs($SECTORS)?></div></div>
<section class="w" id="hizmetler"><h2>Hizmetlerimiz</h2><p class="lead">İhtiyacınız olanı tek tek veya paket olarak alabilirsiniz.</p><?=svc_grid($SERVICES)?></section>
<section class="w"><h2>Çalışma şeklimiz</h2><p class="lead">Dört adımda, net bir takvimle ilerleriz.</p><?=steps()?></section>
<section class="w"><div class="two"><div><h2>Blog</h2><?=plist(posts('blog',3),'/blog')?></div><div><h2>Bizden Haberler</h2><?=plist(posts('haber',3),'/bizden-haberler')?></div></div></section>
<div class="band"><div class="w"><h2>Birlikte çalışalım</h2><p class="lead">Telefon numaranızı bırakın, aynı gün içinde sizi arayalım.</p><div class="actions"><a class="btn" href="/iletisim">Teklif formu</a><a class="btn ghost" href="https://wa.me/<?=wa()?>" target="_blank" rel="noopener">WhatsApp ile yaz</a></div></div></div>
<?php render('AdaVira | Girne Dijital Ajans: Web Tasarım, SEO, Sosyal Medya','Girne merkezli dijital ajans AdaVira: web tasarım ve yazılım, SEO, sosyal medya yönetimi, video ve drone çekimi. Emlak, oto galeri, sağlık, otel ve daha fazlası.',ob_get_clean());break;
case $a==='hizmetler'&&!$b: render('Hizmetlerimiz | AdaVira Girne','Web tasarım, sosyal medya yönetimi, SEO, dijital reklam, marka kimliği ve video prodüksiyon hizmetleri.','<div class="w pg">'.crumb_h([['Hizmetler','']]).'<h1>Hizmetlerimiz</h1>'.svc_grid($SERVICES).'<h2 style="margin-top:56px">Çalışma şeklimiz</h2>'.steps().'</div>',[['Hizmetler','/hizmetler']]);break;
case $a==='hizmet'&&isset($SERVICES[$b]): $v=$SERVICES[$b];render($v[0].' | AdaVira Girne',$v[2],'<div class="w pg">'.crumb_h([['Hizmetler','/hizmetler'],[$v[0],'']]).'<h1>'.e($v[0]).'</h1><p class="lead">'.e($v[2]).'</p><h2>Hangi sektörlere hizmet veriyoruz?</h2>'.cards($SECTORS,'/sektor/',1).'<a class="btn" href="/iletisim">Teklif alın</a></div>',[['Hizmetler','/hizmetler'],[$v[0],'/hizmet/'.$b]]);break;
case $a==='sektorler'&&!$b: render('Sektörler | AdaVira Girne','Emlak, oto galeri, güzellik, spor salonu, sağlık, e-ticaret, otel ve seyahat acenteleri için dijital çözümler.','<div class="band"><div class="w">'.crumb_h([['Sektörler','']]).'<h1>Sektörünüzü tanıyan bir ekip</h1>'.sector_tabs($SECTORS).'</div></div>',[['Sektörler','/sektorler']]);break;
case $a==='sektor'&&isset($SECTORS[$b]): $v=$SECTORS[$b];$li='';foreach($v[3] as $m)$li.='<li>'.e($m).'</li>';render($v[1].' | AdaVira',$v[2],'<div class="w pg">'.crumb_h([['Sektörler','/sektorler'],[$v[0],'']]).'<h1>'.e($v[1]).'</h1><p class="lead">'.e($v[2]).'</p><h2>Sunduğumuz hizmetler</h2><ul class="ck">'.$li.'</ul><a class="btn" href="/iletisim">Bu sektör için teklif alın</a></div>',[['Sektörler','/sektorler'],[$v[0],'/sektor/'.$b]]);break;
case $a==='blog'||$a==='bizden-haberler':
 $t=$a==='blog'?'blog':'haber';$nm=$a==='blog'?'Blog':'Bizden Haberler';
 if($b){$q=db()->prepare('SELECT * FROM posts WHERE type=? AND slug=? AND published=1');$q->execute([$t,$b]);$r=$q->fetch();
  if(!$r){http_response_code(404);render('Sayfa bulunamadı | AdaVira','','<div class="w pg"><h1>404</h1><p>Aradığınız sayfa bulunamadı.</p></div>');break;}
  $al=($r['image_alt']??'')?:$r['title'];$pub=date('c',strtotime($r['created_at']));$mod=date('c',strtotime(($r['updated_at']??'')?:$r['created_at']));
  $cov=($r['image']??'')?'<figure class="cover">'.img_tag($r['image'],$al,$r['image_w']??0,$r['image_h']??0,'(max-width:820px) 100vw, 760px',true).'</figure>':'';
  $oi=img_og($r['image']??'');$OG=['type'=>'article','image'=>$oi,'w'=>($r['image']??'')&&$oi!==$r['image']?1200:($r['image_w']?:1200),'h'=>($r['image']??'')&&$oi!==$r['image']?630:($r['image_h']?:630),'alt'=>$al,'published'=>$pub,'modified'=>$mod];
  $ld='<script type="application/ld+json">'.json_encode(['@context'=>'https://schema.org','@type'=>'Article','headline'=>$r['title'],'description'=>($r['excerpt']?:mb_substr(strip_tags($r['body']),0,155)),'image'=>[SITE.$oi],'datePublished'=>$pub,'dateModified'=>$mod,'mainEntityOfPage'=>['@type'=>'WebPage','@id'=>SITE.'/'.$a.'/'.$b],'author'=>['@type'=>'Organization','name'=>'AdaVira'],'publisher'=>['@type'=>'Organization','name'=>'AdaVira','logo'=>['@type'=>'ImageObject','url'=>SITE.'/icon-192.png']]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).'</script>';
  render($r['title'].' | AdaVira',$r['excerpt']?:mb_substr(strip_tags($r['body']),0,155),'<article class="w pg">'.crumb_h([[$nm,'/'.$a],[$r['title'],'']]).'<h1>'.e($r['title']).'</h1><small>'.e(date('d.m.Y',strtotime($r['created_at']))).'</small>'.$cov.'<div class="prose">'.$r['body'].'</div></article>',[[$nm,'/'.$a],[$r['title'],'/'.$a.'/'.$b]],$ld);break;}
 render($nm.' | AdaVira Girne','AdaVira '.$nm.': dijital pazarlama, SEO ve web tasarım üzerine güncel içerikler.','<div class="w pg">'.crumb_h([[$nm,'']]).'<h1>'.$nm.'</h1>'.plist(posts($t),'/'.$a,true).'</div>',[[$nm,'/'.$a]]);break;
case $a==='hakkimizda':
 mig();$pg=null;try{$q=db()->prepare('SELECT * FROM pages WHERE slug=?');$q->execute(['hakkimizda']);$pg=$q->fetch()?:null;}catch(Throwable $x){}
 $ti=($pg['title']??'')?:'Hakkımızda';$bd=($pg&&trim(strip_tags($pg['body'])))?$pg['body']:'<p>AdaVira, Girne merkezli bir dijital ajanstır. Emlak, oto galeri, güzellik, spor, sağlık, e-ticaret, otel ve turizm işletmelerinin internette görünür olması ve daha fazla müşteriye ulaşması için çalışıyoruz.</p>';
 $ds=($pg['excerpt']??'')?:mb_substr(trim(strip_tags($bd)),0,155);$im=$pg['image']??'';$al=($pg['image_alt']??'')?:$ti;$cov=$im?'<figure class="cover">'.img_tag($im,$al,$pg['image_w'],$pg['image_h'],'(max-width:820px) 100vw, 760px',true).'</figure>':'';
 if($im){$oi=img_og($im);$OG=['image'=>$oi,'w'=>$oi!==$im?1200:($pg['image_w']?:1200),'h'=>$oi!==$im?630:($pg['image_h']?:630),'alt'=>$al];}
 render($ti.' | AdaVira Girne Dijital Ajans',$ds,'<div class="w pg">'.crumb_h([['Hakkımızda','']]).'<h1>'.e($ti).'</h1>'.$cov.'<div class="prose">'.$bd.'</div></div>',[['Hakkımızda','/hakkimizda']]);break;
case $a==='iletisim':
 session_start();mig();$msg='';$good=false;
 $CC=['90'=>'Türkiye (+90)','49'=>'Almanya (+49)','44'=>'Birleşik Krallık (+44)','7'=>'Rusya (+7)','380'=>'Ukrayna (+380)','98'=>'İran (+98)','994'=>'Azerbaycan (+994)','31'=>'Hollanda (+31)','33'=>'Fransa (+33)','1'=>'ABD / Kanada (+1)','357'=>'Güney Kıbrıs (+357)'];
 if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!hash_equals($_SESSION['t']??'x',$_POST['t']??'')||!empty($_POST['website']))$msg='Hata oluştu, tekrar deneyin.';
  elseif(!captcha_ok())$msg='Güvenlik sorusunun cevabı yanlış ya da çok hızlı gönderdiniz. Lütfen tekrar deneyin.';
  else{$n=trim($_POST['name']??'');$cc=$_POST['cc']??'90';if(!isset($CC[$cc]))$cc='90';$ph=preg_replace('/\D/','',$_POST['phone']??'');$sk=mb_substr(trim($_POST['sektor']??''),0,40);$tx=trim($_POST['text']??'');
   if($cc==='90'){$ph=ltrim($ph,'0');$valid=strlen($ph)===10&&$ph[0]==='5';}else $valid=strlen($ph)>=6&&strlen($ph)<=14;
   if(!$n||!$valid||strlen($tx)<5)$msg='Lütfen adınızı, geçerli bir telefon numarasını ((5xx) xxx xx xx) ve mesajınızı yazın.';
   else{$full=$cc==='90'?sprintf('+90 (%s) %s %s %s',substr($ph,0,3),substr($ph,3,3),substr($ph,6,2),substr($ph,8,2)):'+'.$cc.' '.$ph;
    try{db()->prepare('INSERT INTO messages(name,email,phone,body) VALUES(?,?,?,?)')->execute([$n,'',$full,($sk?"Sektör: $sk\n":'').$tx]);}catch(Throwable $x){@error_log(date('c').' DB: '.$x->getMessage()."\n",3,__DIR__.'/../mail-error.log');}
    if(is_file(__DIR__.'/../vendor/autoload.php')){require __DIR__.'/../vendor/autoload.php';try{$M=new PHPMailer\PHPMailer\PHPMailer(true);$M->isSMTP();$sc=env('SMTP_SECURE','ssl');$M->Host=env('SMTP_HOST','localhost');$M->SMTPAuth=true;$M->Username=env('SMTP_USER');$M->Password=env('SMTP_PASS');$M->SMTPSecure=$sc==='none'?'':$sc;$M->SMTPAutoTLS=$sc!=='none';$M->Port=(int)env('SMTP_PORT',465);$M->CharSet='UTF-8';
     if(in_array(env('SMTP_HOST','localhost'),['localhost','127.0.0.1'])||env('SMTP_VERIFY')==='0')$M->SMTPOptions=['ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]];
     $M->setFrom(env('SMTP_USER'),'AdaVira Web');$M->addAddress(env('MAIL_TO'));$M->Subject='Yeni mesaj: '.$n.' '.$full;$M->Body="Ad: $n\nTelefon: $full\nWhatsApp: https://wa.me/$cc$ph\nSektör: $sk\n\n$tx";$M->send();}catch(Throwable $x){@error_log(date('c').' '.$x->getMessage()."\n",3,__DIR__.'/../mail-error.log');}}else @error_log(date('c')." vendor/autoload.php yok\n",3,__DIR__.'/../mail-error.log');
    $_SESSION['last']=time();$good=true;$msg='Mesajınız alındı. En kısa sürede sizi arayacağız.';}}}
 $_SESSION['t']=bin2hex(random_bytes(16));$_SESSION['a']=random_int(2,9);$_SESSION['b']=random_int(2,9);$_SESSION['ts']=time();
 $cap=env('TURNSTILE_SITEKEY')&&env('TURNSTILE_SECRET')?'<div class="cf-turnstile" data-sitekey="'.e(env('TURNSTILE_SITEKEY')).'"></div><script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>':'<label>Güvenlik sorusu: '.$_SESSION['a'].' + '.$_SESSION['b'].' = ? <span class="req">*</span><input name="cap" inputmode="numeric" autocomplete="off" required placeholder="Cevabınız"></label>';
 $opts='';foreach($CC as $k=>$v)$opts.='<option value="'.$k.'">'.e($v).'</option>';
 ob_start();?>
<div class="w pg"><?=crumb_h([['İletişim','']])?><h1>İletişim</h1><div class="contact">
<div class="cinfo"><p class="lead">Projenizi anlatın, size en kısa sürede dönüş yapalım.</p><div class="cbtns"><a class="btn" href="tel:+<?=wa()?>">Hemen ara: <?=e(phone_fmt(wa()))?></a><a class="btn ghost" href="https://wa.me/<?=wa()?>" target="_blank" rel="noopener">WhatsApp'tan yaz</a></div><p>E-posta: <a href="mailto:bilgi@adavira.com">bilgi@adavira.com</a></p><p>Adres: Girne, KKTC</p></div>
<div class="fcard"><h2>Sizi arayalım</h2><?php if($msg):?><p class="<?=$good?'ok':'er'?>" role="alert"><?=e($msg)?></p><?php endif;?>
<form method="post" class="fm"><input type="hidden" name="t" value="<?=$_SESSION['t']?>"><input class="hp" name="website" tabindex="-1" autocomplete="off">
<label>Adınız soyadınız <span class="req">*</span><input name="name" required autocomplete="name" placeholder="Örn. Ahmet Yılmaz"></label>
<label>Telefon numaranız <span class="req">*</span><span class="prow"><select name="cc" id="cc" aria-label="Ülke kodu"><?=$opts?></select><input type="tel" id="phone" name="phone" inputmode="tel" autocomplete="tel-national" required placeholder="(5xx) xxx xx xx"></span></label>
<label>Sektörünüz<select name="sektor"><option>Emlak</option><option>Oto galeri</option><option>Güzellik merkezi</option><option>Spor salonu</option><option>Sağlık</option><option>E-ticaret</option><option>Otel ve turizm</option><option>Diğer</option></select></label>
<label>Mesajınız <span class="req">*</span><textarea name="text" required placeholder="Örn. Yeni web sitesi ve portföy çekimi yaptırmak istiyorum"></textarea></label>
<?=$cap?><button class="btn">Gönder</button></form></div></div></div>
<?php render('İletişim | AdaVira Girne','AdaVira ile iletişime geçin: telefon numaranızı bırakın, sizi arayalım. WhatsApp ve e-posta ile de ulaşabilirsiniz.',ob_get_clean(),[['İletişim','/iletisim']]);break;
case $a==='sitemap.xml':
 header('Content-Type: application/xml; charset=utf-8');$u=[];
 foreach(['/','/hizmetler','/sektorler','/blog','/bizden-haberler','/hakkimizda','/iletisim'] as $x)$u[]=[$x,'',''];
 foreach($SERVICES as $s=>$_)$u[]=['/hizmet/'.$s,'',''];foreach($SECTORS as $s=>$_)$u[]=['/sektor/'.$s,'',''];
 foreach(['blog'=>'/blog/','haber'=>'/bizden-haberler/'] as $t=>$pre)foreach(posts($t) as $r)$u[]=[$pre.$r['slug'],date('Y-m-d',strtotime(($r['updated_at']??'')?:$r['created_at'])),($r['image']??'')?SITE.img_og($r['image']):''];
 echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">';
 foreach($u as $x)echo '<url><loc>'.SITE.e($x[0]).'</loc>'.($x[1]?'<lastmod>'.$x[1].'</lastmod>':'').($x[2]?'<image:image><image:loc>'.e($x[2]).'</image:loc></image:image>':'').'</url>';
 echo '</urlset>';break;
default: http_response_code(404);render('Sayfa bulunamadı | AdaVira','','<div class="w pg"><h1>404</h1><p>Aradığınız sayfa bulunamadı. <a href="/">Ana sayfaya dön</a></p></div>');
}
