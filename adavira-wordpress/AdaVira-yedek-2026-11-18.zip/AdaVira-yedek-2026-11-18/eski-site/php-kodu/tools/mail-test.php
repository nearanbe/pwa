<?php // Plesk > Scheduled Tasks > "Run a PHP script" ile çalıştırın, çıktıyı okuyun
require __DIR__.'/../inc/boot.php';require __DIR__.'/../vendor/autoload.php';
$M=new PHPMailer\PHPMailer\PHPMailer(true);
try{$sc=env('SMTP_SECURE','ssl');$M->isSMTP();$M->SMTPDebug=2;$M->Debugoutput='echo';$M->Host=env('SMTP_HOST','localhost');$M->SMTPAuth=true;$M->Username=env('SMTP_USER');$M->Password=env('SMTP_PASS');$M->SMTPSecure=$sc==='none'?'':$sc;$M->SMTPAutoTLS=$sc!=='none';$M->Port=(int)env('SMTP_PORT',465);$M->CharSet='UTF-8';
if(in_array(env('SMTP_HOST','localhost'),['localhost','127.0.0.1'])||env('SMTP_VERIFY')==='0')$M->SMTPOptions=['ssl'=>['verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed'=>true]];
$M->setFrom(env('SMTP_USER'),'AdaVira Web');$M->addAddress(env('MAIL_TO'));$M->Subject='AdaVira SMTP testi';$M->Body='Bu bir test mesajıdır.';$M->send();echo "\nGONDERILDI\n";}
catch(Throwable $x){echo "\nHATA: ".$x->getMessage()."\n";}
