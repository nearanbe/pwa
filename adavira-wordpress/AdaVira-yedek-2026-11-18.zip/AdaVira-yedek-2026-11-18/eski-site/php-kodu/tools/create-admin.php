<?php // Kullanım: php tools/create-admin.php eposta sifre
require __DIR__.'/../inc/boot.php';if($argc<3)die("Kullanım: php tools/create-admin.php eposta sifre\n");
db()->prepare('REPLACE INTO admins(email,pass_hash) VALUES(?,?)')->execute([$argv[1],password_hash($argv[2],PASSWORD_DEFAULT)]);echo "Yönetici oluşturuldu\n";
