# AdaVira Kurulum (CentOS 8 / Stream, Nginx + PHP + MariaDB)

1. Paketler:
   dnf install -y nginx mariadb-server php php-fpm php-mysqlnd php-mbstring unzip certbot python3-certbot-nginx
   systemctl enable --now nginx mariadb php-fpm
   mysql_secure_installation
2. Dosyalar: zip'i /var/www/ içine aç (klasör adı adavira), sonra:
   chown -R nginx:nginx /var/www/adavira && chcon -R -t httpd_sys_content_t /var/www/adavira
   setsebool -P httpd_can_network_connect 1 && setsebool -P httpd_can_network_connect_db 1
   (php-fpm kullanıcısı nginx değilse /etc/php-fpm.d/www.conf içinde user/group = nginx yapın)
3. Veritabanı:
   mysql -u root -p < /var/www/adavira/sql/schema.sql
   mysql -u root -p -e "CREATE USER 'adavira_user'@'localhost' IDENTIFIED BY 'GUCLU_SIFRE'; GRANT ALL ON adavira.* TO 'adavira_user'@'localhost'; FLUSH PRIVILEGES;"
4. Ayarlar: cd /var/www/adavira && cp .env.example .env && nano .env && chmod 600 .env
   (DB şifresi, e-posta kutusu şifresi, WhatsApp numarası)
5. SMTP için PHPMailer: curl -sS https://getcomposer.org/installer | php && php composer.phar require phpmailer/phpmailer
6. Nginx: cp deploy/nginx-adavira.conf /etc/nginx/conf.d/ && nginx -t && systemctl reload nginx
7. SSL: certbot --nginx -d adavira.com -d www.adavira.com
8. Yönetici: php tools/create-admin.php bilgi@adavira.com SIFREN  -> panel: https://adavira.com/yonetim.php
9. Google Search Console'a adavira.com'u ekle, https://adavira.com/sitemap.xml'i gönder.
Not: .env ve .git gibi dosyalar zaten public/ dışında, web'den erişilemez.
