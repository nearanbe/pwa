<?php
const SITE='https://adavira.com';
$OG=[];
function env($k,$d=''){static $e;if($e===null)$e=@parse_ini_file(__DIR__.'/../.env')?:[];return $e[$k]??$d;}
function db(){static $p;if(!$p)$p=new PDO('mysql:host='.env('DB_HOST','localhost').';dbname='.env('DB_NAME').';charset=utf8mb4',env('DB_USER'),env('DB_PASS'),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);return $p;}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function slugify($s){
    $s = strtr((string)$s, ['İ'=>'i','I'=>'i','ı'=>'i','Ğ'=>'g','ğ'=>'g','Ü'=>'u','ü'=>'u','Ş'=>'s','ş'=>'s','Ö'=>'o','ö'=>'o','Ç'=>'c','ç'=>'c']);
    $s = mb_strtolower($s, 'UTF-8');
    return trim(preg_replace('/[^a-z0-9]+/', '-', $s), '-');
}
function wa(){$n=preg_replace('/\D/','',env('WA_NUMBER'));return strlen($n)>=11?$n:'905488570107';}
function phone_fmt($d){$d=preg_replace('/\D/','',$d);return strlen($d)===12&&substr($d,0,2)==='90'?'+90 '.substr($d,2,3).' '.substr($d,5,3).' '.substr($d,8,2).' '.substr($d,10,2):'+'.$d;}
function mig(){static $d;if($d)return;$d=1;$fl=__DIR__.'/.mig3';if(is_file($fl))return;$f=0;
 try{db()->exec("CREATE TABLE IF NOT EXISTS pages(slug VARCHAR(60) PRIMARY KEY,title VARCHAR(200) NOT NULL DEFAULT '',excerpt VARCHAR(300) NOT NULL DEFAULT '',body MEDIUMTEXT NOT NULL,updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci");}catch(Throwable $x){$f=1;}
 $cols=[['messages','phone',"VARCHAR(40) NOT NULL DEFAULT ''"],['posts','updated_at','DATETIME NULL']];
 foreach(['posts','pages'] as $tb)foreach(['image'=>"VARCHAR(255) NOT NULL DEFAULT ''",'image_alt'=>"VARCHAR(200) NOT NULL DEFAULT ''",'image_w'=>'SMALLINT NOT NULL DEFAULT 0','image_h'=>'SMALLINT NOT NULL DEFAULT 0'] as $c=>$df)$cols[]=[$tb,$c,$df];
 foreach($cols as $c){try{if(!db()->query("SHOW COLUMNS FROM $c[0] LIKE '$c[1]'")->fetch())db()->exec("ALTER TABLE $c[0] ADD $c[1] $c[2]");}catch(Throwable $x){$f=1;}}
 if(!$f)@file_put_contents($fl,'ok');}
function img_ok($p){$p=trim((string)$p);return preg_match('#^/uploads/[\w./-]+\.(webp|jpg|png)$#',$p)&&strpos($p,'..')===false&&is_file(__DIR__.'/../public'.$p)?$p:'';}
function img_sizes($p){if(!preg_match('#^(/uploads/.+)-(\d+)\.(webp|jpg|png)$#',$p,$m))return '';$s=[];foreach(array_unique([400,800,1600,(int)$m[2]]) as $w){$f=$m[1].'-'.$w.'.'.$m[3];if(is_file(__DIR__.'/../public'.$f))$s[$w]=$f.' '.$w.'w';}ksort($s);return count($s)>1?implode(', ',$s):'';}
function img_tag($p,$alt,$w,$h,$sz='100vw',$eager=false){if(!$p)return '';$ss=img_sizes($p);return '<img src="'.e($p).'"'.($ss?' srcset="'.e($ss).'" sizes="'.e($sz).'"':'').' alt="'.e($alt).'"'.($w&&$h?' width="'.(int)$w.'" height="'.(int)$h.'"':'').($eager?' fetchpriority="high"':' loading="lazy"').' decoding="async">';}
function img_og($p){if(!$p)return '/assets/og-default.png';$o=preg_replace('#-\d+\.(webp|jpg|png)$#','',$p).'-og.jpg';return is_file(__DIR__.'/../public'.$o)?$o:$p;}
function og_tags($t,$d){global $OG;$i=$OG['image']??'/assets/og-default.png';$abs=preg_match('#^https?://#',$i)?$i:SITE.$i;
 $h='<meta property="og:image" content="'.e($abs).'"><meta property="og:image:width" content="'.(int)($OG['w']??1200).'"><meta property="og:image:height" content="'.(int)($OG['h']??630).'"><meta property="og:image:alt" content="'.e($OG['alt']??$t).'">';
 $h.='<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="'.e($t).'"><meta name="twitter:description" content="'.e($d).'"><meta name="twitter:image" content="'.e($abs).'">';
 if(($OG['type']??'')==='article'){$h.='<meta property="article:published_time" content="'.e($OG['published']??'').'"><meta property="article:modified_time" content="'.e($OG['modified']??'').'">';}return $h;}
function img_process($tmp,$orig,$kind){
 $inf=@getimagesize($tmp);if(!$inf||!in_array($inf[2],[IMAGETYPE_JPEG,IMAGETYPE_PNG,IMAGETYPE_WEBP],true))return ['error'=>'Sadece JPG, PNG veya WebP görsel yükleyebilirsiniz.'];
 if($inf[0]<300||$inf[1]<150)return ['error'=>'Görsel çok küçük (en az 300 piksel genişlik olmalı).'];
 if($inf[0]*$inf[1]>25000000)return ['error'=>'Görsel çok büyük (en fazla 25 megapiksel).'];
 $dir='/uploads/'.date('Y/m');$abs=__DIR__.'/../public'.$dir;if(!is_dir($abs)&&!@mkdir($abs,0755,true))return ['error'=>'Yükleme klasörü oluşturulamadı.'];
 $nm=substr(slugify(pathinfo($orig,PATHINFO_FILENAME))?:'gorsel',0,50).'-'.bin2hex(random_bytes(3));
 if(!function_exists('imagecreatefromstring')||!function_exists('imagewebp')){$ext=[IMAGETYPE_JPEG=>'jpg',IMAGETYPE_PNG=>'png',IMAGETYPE_WEBP=>'webp'][$inf[2]];$f=$abs.'/'.$nm.'-'.$inf[0].'.'.$ext;if(!@move_uploaded_file($tmp,$f))return ['error'=>'Dosya kaydedilemedi.'];return ['url'=>$dir.'/'.$nm.'-'.$inf[0].'.'.$ext,'w'=>$inf[0],'h'=>$inf[1]];}
 $im=@imagecreatefromstring(file_get_contents($tmp));if(!$im)return ['error'=>'Görsel okunamadı.'];
 if($inf[2]===IMAGETYPE_JPEG&&function_exists('exif_read_data')){$ex=@exif_read_data($tmp);$ang=[3=>180,6=>-90,8=>90][$ex['Orientation']??1]??0;if($ang)$im=imagerotate($im,$ang,0);}
 $W=imagesx($im);$H=imagesy($im);$out=[];
 foreach($kind==='cover'?[1600,800,400]:[1200] as $w){$tw=min($w,$W);if($out&&$tw>=$out[0][0])continue;$th=(int)round($H*$tw/$W);
  $c=imagecreatetruecolor($tw,$th);imagealphablending($c,false);imagesavealpha($c,true);imagefill($c,0,0,imagecolorallocatealpha($c,255,255,255,127));imagecopyresampled($c,$im,0,0,0,0,$tw,$th,$W,$H);
  if(!@imagewebp($c,$abs.'/'.$nm.'-'.$tw.'.webp',82))return ['error'=>'Görsel kaydedilemedi.'];imagedestroy($c);$out[]=[$tw,$th];}
 if($kind==='cover'){$ow=1200;$oh=630;$r=max($ow/$W,$oh/$H);$cw=(int)round($ow/$r);$ch=(int)round($oh/$r);$c=imagecreatetruecolor($ow,$oh);imagefill($c,0,0,imagecolorallocate($c,255,255,255));imagecopyresampled($c,$im,0,0,(int)(($W-$cw)/2),(int)(($H-$ch)/2),$ow,$oh,$cw,$ch);@imagejpeg($c,$abs.'/'.$nm.'-og.jpg',86);imagedestroy($c);}
 imagedestroy($im);return ['url'=>$dir.'/'.$nm.'-'.$out[0][0].'.webp','w'=>$out[0][0],'h'=>$out[0][1]];}
function clean_html($h){
 $h=trim((string)$h);if($h==='')return '';
 $ok=['p','br','h2','h3','h4','strong','b','em','i','u','s','a','ul','ol','li','blockquote','span','img'];
 if(!class_exists('DOMDocument'))return strip_tags($h,'<p><br><h2><h3><h4><strong><em><u><s><a><ul><ol><li><blockquote><span>');
 $d=new DOMDocument();libxml_use_internal_errors(true);
 $d->loadHTML('<?xml encoding="utf-8"?><div id="r">'.$h.'</div>',LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);libxml_clear_errors();
 $r=$d->getElementById('r');if(!$r)return '';
 $w=null;$w=function($n)use(&$w,$ok){
  foreach(iterator_to_array($n->childNodes) as $c){
   if($c->nodeType===XML_TEXT_NODE)continue;
   if($c->nodeType!==XML_ELEMENT_NODE){$n->removeChild($c);continue;}
   $t=strtolower($c->nodeName);
   if(!in_array($t,$ok,true)){
    if(in_array($t,['script','style','iframe','object','embed','form','svg','math','noscript','template'],true)){$n->removeChild($c);continue;}
    $w($c);while($c->firstChild)$n->insertBefore($c->firstChild,$c);$n->removeChild($c);continue;}
   $w($c);
   foreach(iterator_to_array($c->attributes) as $at){$nm=strtolower($at->name);
    if($nm==='class'){$k=array_filter(preg_split('/\s+/',$at->value),function($x){return preg_match('/^ql-(size-(small|large|huge)|align-(center|right|justify)|indent-[1-8])$/',$x);});if($k)$c->setAttribute('class',implode(' ',$k));else $c->removeAttribute('class');}
    elseif($t==='a'&&$nm==='href'){}elseif($t==='img'&&in_array($nm,['src','alt','width','height'],true)){}
    else $c->removeAttribute($at->name);}
   if($t==='img'){$sr=$c->getAttribute('src');if(!img_ok($sr)){$n->removeChild($c);continue;}$c->setAttribute('alt',mb_substr($c->getAttribute('alt'),0,200));foreach(['width','height'] as $k)if($c->hasAttribute($k)&&!ctype_digit($c->getAttribute($k)))$c->removeAttribute($k);$c->setAttribute('loading','lazy');$c->setAttribute('decoding','async');}
   if($t==='a'){$u=trim($c->getAttribute('href'));
    if(!preg_match('#^(https?://|mailto:|tel:|/|\#)#i',$u)){$u=preg_match('#^[\w.-]+\.[a-z]{2,}(/.*)?$#i',$u)?'https://'.$u:'';}
    if($u===''){while($c->firstChild)$n->insertBefore($c->firstChild,$c);$n->removeChild($c);continue;}
    $c->setAttribute('href',$u);
    if(preg_match('#^(/(?!/)|\#|https?://(www\.)?adavira\.com)#i',$u)){$c->removeAttribute('target');$c->removeAttribute('rel');}
    else{$c->setAttribute('target','_blank');$c->setAttribute('rel','noopener');}}
  }};
 $w($r);$o='';foreach($r->childNodes as $c)$o.=$d->saveHTML($c);
 return trim($o);
}
function social_html(){$ic=[
'facebook'=>['Facebook','<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>'],
'instagram'=>['Instagram','<rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>'],
'x'=>['X','<path d="M4 4l16 16M20 4L4 20"/>'],
'youtube'=>['YouTube','<path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/>'],
'linkedin'=>['LinkedIn','<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>'],
'tiktok'=>['TikTok','<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>'],
'whatsapp'=>['WhatsApp','<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>']];
$h='';foreach($ic as $k=>$v){$u=$k==='whatsapp'?'https://wa.me/'.wa():env('SOCIAL_'.strtoupper($k),'');$h.='<a href="'.e($u?:'#').'" target="_blank" rel="noopener nofollow" aria-label="'.$v[0].'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$v[1].'</svg><span>'.$v[0].'</span></a>';}return $h;}
// slug => [ad, footer anahtar kelime, açıklama, maddeler]
$SECTORS=[
'emlak'=>['Emlak Ofisleri','Girne Emlak Ofisi Web Sitesi','İlan sitesi, iç/dış mekân çekimi, drone çekimi ve AI asistan otomasyonu ile emlak ofisinizi öne çıkarın.',['İlan odaklı web sitesi','İç ve dış mekân profesyonel çekim','Drone çekimi','AI asistan otomasyonu','Google SEO']],
'oto-galeri'=>['Oto Galeriler','Girne Oto Galeri Web Sitesi','Araç stokunuzu vitrine çıkaran web sitesi, video ve çekim hizmetleri.',['Araç stok web sitesi','Showroom ve araç çekimi','Drone ve video editing','Google SEO']],
'guzellik-merkezi'=>['Güzellik Merkezleri','Girne Güzellik Merkezi Reklam','Randevu odaklı site, sosyal medya yönetimi ve reklam çözümleri.',['Randevu odaklı web sitesi','Sosyal medya yönetimi','Instagram reklamları','Google SEO']],
'spor-salonu'=>['Spor Salonları','Girne Spor Salonu Pazarlama','Üyelik kazandıran site, sosyal medya ve tanıtım videosu.',['Üyelik odaklı site','Tanıtım videosu','Sosyal medya yönetimi','Yerel SEO']],
'saglik'=>['Sağlık: Hastane, Psikolog, Diyetisyen, Tüp Bebek','Girne Psikolog ve Diyetisyen Web Sitesi','Hastane, psikolog, diyetisyen ve tüp bebek merkezleri için güven veren kurumsal web siteleri ve dijital tanıtım.',['Kurumsal web sitesi','Online randevu','Yerel SEO','Sosyal medya yönetimi']],
'e-ticaret'=>['E-Ticaret','KKTC E-Ticaret Sitesi Kurulumu','Satış getiren e-ticaret altyapısı, ürün çekimi ve dijital reklam.',['E-ticaret sitesi','Ürün çekimi','Google ve sosyal medya reklamları','SEO']],
'otel'=>['Oteller','Girne Otel Web Sitesi ve SEO','Doğrudan rezervasyon getiren otel siteleri, tanıtım filmi ve drone çekimi.',['Rezervasyon odaklı site','Tanıtım filmi ve drone','Çok dilli SEO','Dijital reklam']],
'seyahat-acentesi'=>['Seyahat Acenteleri','Girne Seyahat Acentesi Web Sitesi','Tur ve bilet satışını artıran site, içerik ve reklam yönetimi.',['Tur odaklı web sitesi','Sosyal medya yönetimi','Google reklamları','SEO']],
];
$SERVICES=[
'web-tasarim-yazilim'=>['Web tasarım ve yazılım','Girne Web Tasarım','Hızlı, mobil uyumlu kurumsal siteler, ilan ve stok vitrinleri, randevu sayfaları.'],
'sosyal-medya-yonetimi'=>['Sosyal medya yönetimi','Girne Sosyal Medya Yönetimi','İçerik planı, paylaşım, topluluk yönetimi ve aylık raporlama.'],
'seo-yerel-arama'=>['SEO ve yerel arama','Girne SEO Hizmeti','Google Haritalar ve arama sonuçlarında bölgenizde ilk sayfaya çıkın.'],
'dijital-reklam'=>['Dijital reklam','Girne Google ve Meta Reklam','Google ve Meta reklamları. Bütçeniz ölçülür, sonuç raporlanır.'],
'marka-kimligi'=>['Marka kimliği','Girne Logo ve Kurumsal Kimlik','Logo, renk, yazı tipi ve tüm basılı ve dijital malzemeler.'],
'video-drone-produksiyon'=>['Video ve drone prodüksiyon','Girne Video ve Drone Çekimi','İç ve dış mekân çekimi, drone görüntüsü, kurgu ve renk düzenleme.'],
];
$SLOG=[
'emlak'=>['Portföyünüz, doğru görüntüyle hızlı satılır.','Alıcı ilanı açmadan önce fotoğrafa ve videoya bakar. İlanlarınızı profesyonel çekimle öne çıkarırız.'],
'oto-galeri'=>['Her araç için güçlü bir vitrin.','Stoktaki araçlarınızı sahibinden dışında da müşteriye ulaştıran bir yapı kurarız.'],
'guzellik-merkezi'=>['Güveni görselle kuran bir tanıtım.','Hizmetinizi, ekibinizi ve sonuçlarınızı müşterinin göreceği şekilde anlatırız.'],
'spor-salonu'=>['Üyelik başvurusunu artıran içerik.','Salonunuzun enerjisini ve ekipmanını çekimle, kampanyalarınızı reklamla duyururuz.'],
'saglik'=>['Güven veren bir dijital ilk izlenim.','Hasta ve danışanlar karar vermeden önce internette araştırır. Güven veren bir site ve doğru içerikle öne çıkarız.'],
'e-ticaret'=>['Ziyaretçiyi müşteriye çeviren mağaza.','Hızlı bir mağaza, net ürün görselleri ve ölçülen reklamlarla satışı artırırız.'],
'otel'=>['Doğrudan rezervasyonu artıran vitrin.','Konuk odayı görmeden karar vermez. Otelinizi film, drone ve çok dilli bir siteyle anlatırız.'],
'seyahat-acentesi'=>['Tur satışını artıran net bir vitrin.','Turlarınızı, fiyatlarınızı ve yorumları tek sayfada toplayıp reklamla doğru kitleye ulaştırırız.'],
];
function render($title,$desc,$body,$crumbs=[],$extra=''){
global $SECTORS,$SERVICES,$OG;
$url=SITE.strtok($_SERVER['REQUEST_URI'],'?');$wa=wa();
$org=['@context'=>'https://schema.org','@type'=>'ProfessionalService','name'=>'AdaVira','url'=>SITE,'logo'=>SITE.'/icon-192.png','image'=>SITE.'/assets/og-default.png','email'=>'bilgi@adavira.com','address'=>['@type'=>'PostalAddress','addressLocality'=>'Girne','addressCountry'=>'CY'],'areaServed'=>'Kuzey Kıbrıs','description'=>'Girne merkezli dijital ajans: web tasarım, SEO, sosyal medya, video prodüksiyon.'];
$bc='';if($crumbs){$it=[['@type'=>'ListItem','position'=>1,'name'=>'Ana Sayfa','item'=>SITE.'/']];foreach($crumbs as $i=>$c)$it[]=['@type'=>'ListItem','position'=>$i+2,'name'=>$c[0],'item'=>SITE.$c[1]];$bc='<script type="application/ld+json">'.json_encode(['@context'=>'https://schema.org','@type'=>'BreadcrumbList','itemListElement'=>$it],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).'</script>';}
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($title)?></title><meta name="description" content="<?=e($desc)?>"><link rel="canonical" href="<?=e($url)?>">
<meta property="og:type" content="<?=e($OG['type']??'website')?>"><meta property="og:title" content="<?=e($title)?>"><meta property="og:description" content="<?=e($desc)?>"><meta property="og:url" content="<?=e($url)?>"><meta property="og:locale" content="tr_TR"><meta property="og:site_name" content="AdaVira"><?=og_tags($title,$desc)?><meta name="theme-color" content="#0f1b2d">
<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="icon" href="/favicon-32.png" sizes="32x32" type="image/png"><link rel="apple-touch-icon" href="/apple-touch-icon.png"><script src="/assets/app.js?v=<?=@filemtime(__DIR__.'/../public/assets/app.js')?>" defer></script><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600&family=Manrope:wght@400;500;600&display=swap" rel="stylesheet"><link rel="stylesheet" href="/assets/style.css?v=<?=@filemtime(__DIR__.'/../public/assets/style.css')?>"><script type="application/ld+json"><?=json_encode($org,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?></script><?=$bc.$extra?></head><body>
<header><div class="w nav"><a class="logo" href="/">AdaVira</a><button id="menu" class="burger" aria-label="Menüyü aç" aria-expanded="false"><span></span></button><nav id="nav"><a href="/sektorler">Sektörler</a><a href="/hizmetler">Hizmetler</a><a href="/blog">Blog</a><a href="/bizden-haberler">Bizden Haberler</a><a href="/hakkimizda">Hakkımızda</a><a class="btn" href="/iletisim">İletişim</a></nav></div></header>
<main><?=$body?></main>
<footer><div class="w fg">
<div><h4>AdaVira</h4><p>Girne merkezli dijital ajans. Web tasarım, SEO, sosyal medya ve video prodüksiyon.</p><p><a href="mailto:bilgi@adavira.com">bilgi@adavira.com</a></p><p><a href="tel:+<?=$wa?>"><?=e(phone_fmt($wa))?></a></p></div>
<div><h4>Hizmetler</h4><?php foreach($SERVICES as $s=>$v)echo '<a href="/hizmet/'.$s.'">'.e($v[1]).'</a>';?></div>
<div><h4>Sektörlere Özel</h4><?php foreach($SECTORS as $s=>$v)echo '<a href="/sektor/'.$s.'">'.e($v[1]).'</a>';?></div>
<div><h4>Kurumsal</h4><a href="/hakkimizda">Hakkımızda</a><a href="/blog">Blog</a><a href="/bizden-haberler">Bizden Haberler</a><a href="/iletisim">İletişim</a><a href="/sitemap.xml">Site Haritası</a></div>
<div class="sl"><h4>Bizi takip edin</h4><?=social_html()?></div>
</div><div class="w seo">AdaVira Dijital Ajans · Girne, Kuzey Kıbrıs · Pazartesi – Cumartesi: 09:00 – 18:00</div><div class="w cp">© <?=date('Y')?> AdaVira · Ozanköy - Girne / KKTC </div></footer>
<?php if($wa):?><a class="wa" href="https://wa.me/<?=$wa?>" target="_blank" rel="noopener" aria-label="WhatsApp ile yazın">WhatsApp</a><?php endif;?><div class="mbar"><a href="tel:+<?=$wa?>">Ara</a><a href="https://wa.me/<?=$wa?>" target="_blank" rel="noopener">WhatsApp</a></div></body></html><?php }
function crumb_h($a){$h='<p class="bc"><a href="/">Ana Sayfa</a>';foreach($a as $c)$h.=' › '.($c[1]?'<a href="'.$c[1].'">'.e($c[0]).'</a>':e($c[0]));return $h.'</p>';}
