<?php defined('ABSPATH') || exit; $wa = adv_wa(); $cur = adv_req_path();
$nav = ['/sektorler' => 'Sektörler', '/hizmetler' => 'Hizmetler', '/blog' => 'Blog', '/bizden-haberler' => 'Bizden Haberler', '/hakkimizda' => 'Hakkımızda'];
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#main">İçeriğe geç</a>
<header class="hdr">
	<div class="w nav">
		<a class="logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="AdaVira ana sayfa">
			<?php echo adv_logo(); ?>
		</a>
		<button id="menu" class="burger" aria-label="Menüyü aç" aria-expanded="false" aria-controls="nav"><span></span></button>
		<nav id="nav" aria-label="Ana menü">
			<?php foreach ($nav as $u => $t): $on = $cur === $u || strpos($cur, $u . '/') === 0 || ($u === '/sektorler' && strpos($cur, '/sektor/') === 0) || ($u === '/hizmetler' && strpos($cur, '/hizmet/') === 0); ?>
			<a href="<?php echo esc_url(home_url($u)); ?>"<?php echo $on ? ' aria-current="page"' : ''; ?>><?php echo esc_html($t); ?></a>
			<?php endforeach; ?>
			<a class="btn sm" href="<?php echo esc_url(home_url('/iletisim')); ?>">Teklif alın</a>
		</nav>
	</div>
</header>
<main id="main">
